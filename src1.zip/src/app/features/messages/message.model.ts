export interface Message {
  id: number;
  from: string;
  to: string;
  text: string;
  time: string;
  read: boolean;
}
