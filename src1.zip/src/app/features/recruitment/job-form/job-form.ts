import { Component } from '@angular/core';

@Component({
  selector: 'app-job-form',
  imports: [],
  templateUrl: './job-form.html',
  styleUrl: './job-form.css',
})
export class JobForm {

}
