declare module 'moment-jalaali';
