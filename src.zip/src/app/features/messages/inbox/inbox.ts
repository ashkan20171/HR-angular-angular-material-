import { Component } from '@angular/core';

@Component({
  selector: 'app-inbox',
  imports: [],
  templateUrl: './inbox.html',
  styleUrl: './inbox.css',
})
export class Inbox {

}
