import { Component } from '@angular/core';

@Component({
  selector: 'app-kpi-chart',
  imports: [],
  templateUrl: './kpi-chart.html',
  styleUrl: './kpi-chart.css',
})
export class KpiChart {

}
