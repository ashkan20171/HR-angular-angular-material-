import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-review',
  imports: [],
  templateUrl: './manager-review.html',
  styleUrl: './manager-review.css',
})
export class ManagerReview {

}
