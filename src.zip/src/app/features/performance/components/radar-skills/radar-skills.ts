import { Component } from '@angular/core';

@Component({
  selector: 'app-radar-skills',
  imports: [],
  templateUrl: './radar-skills.html',
  styleUrl: './radar-skills.css',
})
export class RadarSkills {

}
