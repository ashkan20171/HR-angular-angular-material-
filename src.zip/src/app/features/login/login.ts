import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { RecaptchaModule } from 'ng-recaptcha';
import { TranslateService, TranslateModule } from '@ngx-translate/core';
import { AuthService } from '../../core/auth/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.html',
  styleUrl: './login.css',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    RecaptchaModule,
    TranslateModule
  ]
})
export class Login implements OnInit {

  loginForm!: FormGroup;
  captchaOk = false;
  currentBg = '';
  currentDirection: 'rtl' | 'ltr' = 'rtl';

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private translate: TranslateService,
    private auth: AuthService
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.setSeasonBackground();
  }

  setSeasonBackground(): void {
    const m = new Date().getMonth() + 1;

    this.currentBg =
      m >= 3 && m <= 5 ? '/assets/bg/spring.jpg' :
      m >= 6 && m <= 8 ? '/assets/bg/summer.jpg' :
      m >= 9 && m <= 11 ? '/assets/bg/autumn.jpg' :
      '/assets/bg/winter.jpg';
  }

  changeLang(lang: string): void {
    this.translate.use(lang);
    this.currentDirection = lang === 'fa' ? 'rtl' : 'ltr';
  }

  onCaptchaResolved(token: string | null): void {
    this.captchaOk = !!token;
  }

  onSubmit(): void {
    // اگر فرم یا کپچا معتبر نیست
    if (this.loginForm.invalid || !this.captchaOk) {
      return;
    }

    const { username, password } = this.loginForm.value;

    const success = this.auth.login(username, password);

    if (!success) {
      alert('نام کاربری یا رمز عبور اشتباه است');
      return;
    }

    // مسیر صحیح داشبورد
    this.router.navigate(['/app/dashboard']);
  }
}
